package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    EditText edt1;
    EditText edt2;
    EditText edt3;
    Button btn1;
    TextView txtRes1;
    TextView txtRes2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        edt1 = findViewById((R.id.edt1));
        edt2 = findViewById((R.id.edt2));
        edt3 = findViewById((R.id.edt3));
        btn1 = findViewById((R.id.btn1));
        txtRes1 = findViewById((R.id.txtRes1));
        txtRes2 = findViewById((R.id.txtRes2));
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double v1, v2, v3, res1, res2;
                v1=Double.parseDouble(edt1.getText().toString());
                v2=Double.parseDouble(edt2.getText().toString());
                v3=Double.parseDouble(edt3.getText().toString());
                res1=(v1*v2)/1000;
                res2=res1*v3;
                txtRes1.setText("Consumo de energia em quilowatts/hora: "+res1+" kW/h");
                txtRes2.setText("Preço de energia por kwh: R$"+res2);
            }
        });


    }
}